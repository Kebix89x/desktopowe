let express = require("express");
let app = express();

app.use(express.static("public"));

app.get("/",function(req,res){
   
    res.send("Strona glowna");

});

app.get("/o-nas",function(req,res){
   
    res.send("O nas!");

});


app.get("/blog/:date/:id",function(req,res){
   
    res.send("Strona glowna");

});

app.listen(8080,function(){

    console.log("Serwer został uruchomiony pod adresem http://localhost:8080");
});